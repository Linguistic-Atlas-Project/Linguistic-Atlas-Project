General Corpus Information: 2011-07-08: Lamont Antieau

This is a collection of field records from the Linguistic Atlas of the Middle Rockies, a component of the larger Linguistic Atlas of the Western States, a project that began under the direction of Lee Pederson in 1988. Transcription of all interviews currently in the collection ended in May 2011, and personal information was redacted from the transcripts during the period from May to July 2011; editing is ongoing. Below are a list of codes for nonlinguistic or paralinguistic sounds that appear in the interviews, along with their definitions.  

Transcript Codes

P: Prompt by fieldworker
R: Response by informant
S: Response by secondary informant (typically spouse of primary informant, but can be any supplementary informant. Multiple supplementary informants are labeled S1, S2...)

G(A): Grunt, affirmation
G(N): Grunt, negation
G(Q): Grunt, question, "Is that right?"
G(U): Grunt, neutral
U(C): Utterance, cough
U(F): Utterance, false start
U(H): Utterance, hesitation
U(I): Utterance, interruption
U(L): Utterance, laughter
U(M): Utterance mumbled, inaudible
U(W): Utterance, whisper
U(X): Redacted information

Program = tape side

Several notes such as "recorder is turned off and then back on" or comments about noise have yet to be codified in this version of the release.

All original records have been archived by the Linguistic Atlas Office at the University of Georgia.

----------------------------------------------------------------------
Note on Normalization: 2011-07-25: Clayton Darwin
View as plain text, fixed-with font (Courier), wrap 72 or higher.

1) All files converted to plain-text UTF-8, no initial byte-order mark (BOM).

2) As much as possible, characters with ordinal values greater than 127 were replaced with equivalent characters with values less than 128.  In particular, left and right quotes, various dashes, and diaeresis characters.  This was done as an aid to searching (i.e. you know what to expect, and you can use your keyboard characters).  The Python code used is the following:

        # replace apostrophe and single quotes
        data = data.replace('\x91','\'')
        data = data.replace('\x92','\'')

        # also double parentheses
        data = data.replace('\x93','"')
        data = data.replace('\x94','"')

        # also dashes
        data = data.replace('\x96','-')
        data = data.replace('\x97','--')

        # also diaeresis
        data = data.replace('\x85','...')

3) Diaeresis were shortened to a maximum of 3 dot characters.

        # long diaeresis
        data = re.sub('\.{4,}','...',data)

4) Tape programs were normalized.  Tapes were numbered I, II, III.  Sides were designated A and B.  Inconsistencies were repaired to the extent possible, and notes added where repairs were not possible.  The format is as such:

        PROGRAM IA START
        PROGRAM IA END
        PROGRAM IB START
        PROGRAM IB END
        PROGRAM IIA START
        PROGRAM IIA END

5) All prompt, response and spurious lines were numbered according to the current prompt count.  All text data lines now start with a 4-digit numbering sequence starting with 0001 per file.

        0015 P: Traveled outside of the United States any?
        0015 R: Just Hawaii and Mexico. That's all I been.
        
        0016 P: Were you in the service?
        0016 R: Yeah.
        
        0017 P: Okay.
        0017 R: I was in the Navy.

6) All spurious lines were converted to the "S" format.  "T" lines became "S2" lines, and "U" lines became "S3" lines.

7) All comment lines were separated from the text and put into parentheses: (any comment).

8) All text data for a given prompt, response and spurious line was put on a single line (newlines were removed), to the extent possible, when comments and program changes didn't separate.  DO NOT be deceived by word wrap into thinking there are newlines in the text data (turn off word wrap and look), and DO NOT add them.

9) Equal-numbered prompt, response and spurious lines are blocked together (have no newlines between them, separated from other blocks by two newlines), to the extent possible, when comments and program changes didn't separate.

10) All whitespace was normalized to only one space between words/sentences, and a maximum of two consecutive newlines anywhere in a file.  

11) Previous turn numbering, "RENUMBER", and "#" lines were removed.

12) Breaks designated by a string of asterisks and spaces on a single line were replaced by the comment "(break)".

13) Note: In the final text, all lines start with an open parenthesis (comments), "PROGRAM" (program markers), or a 4-digit number (prompt, response and spurious lines), or it is an empty line.

14) Unrecognized lines were marked and subsequently checked manually and repaired.  Of the original 400+ lines marked, most were the result of newlines inside a prompt, response or spurious "line".  The remainder were program numbering errors and comments.

15) IMPORTANT: Editing should ONLY be done using a plain-text editor capable of encoding the files as UTF-8 with no BOM.  I recommend using EditPadPro.  Microsoft products tend to include a BOM and may replace characters.  Also, make sure the editor (program) does not convert wrapping into newlines, and make sure the editors (people) do not add new lines into the prompt, response and spurious lines.  Adhering to the existing conventions will make normalizing post-editing much easier.      

----------------------------------------------------------------------